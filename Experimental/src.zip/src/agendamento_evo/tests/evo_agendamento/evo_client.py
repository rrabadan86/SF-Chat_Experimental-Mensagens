# Cliente da API do EVO (W12 / abcevo).
# Doc: https://evo-integracao.w12app.com.br/swagger  |  Auth: Basic (DNS + Secret Key).
import logging

import requests
from requests.auth import HTTPBasicAuth

from . import config
from .util import fmt_date_evo, fmt_datetime_evo, only_digits

log = logging.getLogger("evo")


class EvoError(RuntimeError):
    """Erro retornado pela API do EVO (com as mensagens quando disponíveis)."""


class EvoClient:
    def __init__(self, dns=None, token=None, base_url=None, branch_id=None, timeout=None):
        self.base_url = (base_url or config.EVO_BASE_URL).rstrip("/")
        dns = dns if dns is not None else config.EVO_DNS
        token = token if token is not None else config.EVO_TOKEN
        if not dns or not token:
            raise EvoError("EVO_DNS e EVO_TOKEN são obrigatórios (Basic auth).")
        self.auth = HTTPBasicAuth(dns, token)
        _branch = branch_id if branch_id is not None else config.EVO_BRANCH_ID
        self.branch_id = int(_branch) if str(_branch).strip() else None
        self.timeout = timeout or config.EVO_TIMEOUT
        self.session = requests.Session()

    # --------------- baixo nível ---------------
    def _request(self, method, path, params=None, json=None):
        url = f"{self.base_url}{path}"
        resp = self.session.request(
            method, url,
            params=_drop_empty(params), json=json, auth=self.auth,
            timeout=self.timeout, headers={"Accept": "application/json"},
        )
        if not resp.ok:
            raise EvoError(f"EVO {method} {path} -> HTTP {resp.status_code}: {_error_detail(resp)}")
        if resp.status_code == 204 or not resp.content:
            return None
        try:
            return resp.json()
        except ValueError:
            return resp.text

    def _bid(self, branch_id):
        return branch_id if branch_id is not None else self.branch_id

    # --------------- prospects (cadastro) ---------------
    def find_prospects(self, email=None, phone=None):
        """Busca prospects por e-mail e/ou telefone. Retorna lista (pode ser vazia)."""
        params = {"take": 50}
        if email:
            params["email"] = email
        if phone:
            params["phone"] = only_digits(phone)
        data = self._request("GET", "/api/v1/prospects", params=params) or []
        return data if isinstance(data, list) else []

    def create_prospect(self, name, last_name=None, email=None, phone=None,
                        ddi=None, branch_id=None, notes=None):
        """Cadastra um prospect (aluno em potencial). Retorna idProspect."""
        body = {
            "name": name,
            "lastName": last_name,
            "email": email,
            "cellphone": only_digits(phone),
            "ddi": ddi or config.EVO_DDI,
            "notes": notes,
        }
        bid = self._bid(branch_id)
        if bid:
            body["idBranch"] = bid
        data = self._request("POST", "/api/v1/prospects", json=_drop_empty(body))
        id_prospect = (data or {}).get("idProspect")
        if not id_prospect:
            raise EvoError(f"Cadastro não retornou idProspect: {data!r}")
        log.info("Prospect criado: idProspect=%s (%s)", id_prospect, name)
        return id_prospect

    def get_or_create_prospect(self, name, last_name=None, email=None, phone=None,
                               ddi=None, branch_id=None):
        """Idempotência: reaproveita prospect existente (por e-mail, depois telefone)
        ou cria um novo. Retorna (idProspect, criado?)."""
        for key, val in (("email", email), ("phone", phone)):
            if not val:
                continue
            found = self.find_prospects(**{key: val})
            if found and found[0].get("idProspect"):
                idp = found[0]["idProspect"]
                log.info("Prospect já existe (%s=%s): idProspect=%s", key, val, idp)
                return idp, False
        return self.create_prospect(name, last_name, email, phone, ddi, branch_id), True

    # --------------- serviços / horários (descoberta) ---------------
    def list_services(self, experimental_only=False, branch_id=None):
        """Lista serviços. Com experimental_only=True, filtra os que liberam aula
        experimental (flag experimentalClass)."""
        params = {"take": 50, "showActivities": True}
        bid = self._bid(branch_id)
        if bid:
            params["idBranch"] = bid
        data = self._request("GET", "/api/v1/service", params=params) or []
        if experimental_only:
            data = [s for s in data if s.get("experimentalClass")]
        return data

    def list_activities(self, search="", branch_id=None):
        """Lista atividades (aulas) da academia."""
        params = {"take": 50, "search": search}
        bid = self._bid(branch_id)
        if bid:
            params["idBranch"] = bid
        return self._request("GET", "/api/v1/activities", params=params) or []

    def list_experimental_schedule(self, date, show_full_week=True, branch_id=None):
        """Horários que aceitam aula experimental a partir de uma data.
        Retorna itens com allowExperimentalClass / experimentalClassSlots / activityDate."""
        params = {
            "experimentalClass": True,
            "date": fmt_date_evo(date),
            "showFullWeek": show_full_week,
            "onlyAvailables": True,
        }
        bid = self._bid(branch_id)
        if bid:
            params["idBranch"] = bid
        return self._request("GET", "/api/v1/activities/schedule", params=params) or []

    def list_schedule(self, date, show_full_week=False, only_availables=False, branch_id=None):
        """Agenda de turmas (sem filtro de aula experimental). Traz idConfiguration,
        startTime, capacity e ocupation — usada para achar a turma do horário e checar vaga."""
        params = {
            "date": fmt_date_evo(date),
            "showFullWeek": show_full_week,
            "onlyAvailables": only_availables,
        }
        bid = self._bid(branch_id)
        if bid:
            params["idBranch"] = bid
        return self._request("GET", "/api/v1/activities/schedule", params=params) or []

    # --------------- venda do serviço ---------------
    def create_sale(self, id_service, id_prospect=None, id_member=None,
                    service_value=0.0, payment=None, total_installments=1, branch_id=None):
        """Vende um serviço (ex.: 'Aula Experimental') para um prospect/aluno.
        Espelha o passo manual de 'vender o serviço para a oportunidade'."""
        body = {
            "idService": int(id_service),
            "serviceValue": service_value,
            "totalInstallments": total_installments,
        }
        if id_prospect:
            body["idProspect"] = int(id_prospect)
        if id_member:
            body["idMember"] = int(id_member)
        if payment not in (None, ""):
            body["payment"] = int(payment)
        bid = self._bid(branch_id)
        if bid:
            body["idBranch"] = bid
        data = self._request("POST", "/api/v1/sales", json=body)
        log.info("Serviço vendido (idService=%s) para prospect=%s", id_service, id_prospect)
        return data

    # --------------- matrícula na turma (agendamento normal) ---------------
    def enroll_schedule(self, id_configuration, activity_date, id_prospect=None,
                        id_member=None, slot_number=0, origin=None):
        """Matricula o prospect/aluno numa turma (agendamento normal).
        activity_date: data da turma (yyyy-MM-dd); a turma é identificada pelo idConfiguration."""
        params = {
            "idConfiguration": int(id_configuration),
            "activityDate": fmt_date_evo(activity_date),
            "slotNumber": slot_number,
        }
        if id_prospect:
            params["idProspect"] = int(id_prospect)
        if id_member:
            params["idMember"] = int(id_member)
        if origin is not None:
            params["origin"] = origin
        data = self._request("POST", "/api/v1/activities/schedule/enroll", params=params)
        log.info("Matriculado na turma idConfiguration=%s em %s (prospect=%s)",
                 id_configuration, params["activityDate"], id_prospect)
        return data

    # --------------- agendamento da aula experimental ---------------
    def book_experimental_class(self, id_prospect, activity_date, activity=None,
                                service=None, id_activity=None, id_service=None,
                                branch_id=None, activity_exist=None):
        """Cria a aula experimental, vende o serviço e matricula o prospect.
        Um único endpoint cobre venda + agendamento. Retorna idActivitySession.

        Identifique a atividade/serviço por nome (activity/service) OU por id
        (id_activity/id_service). activity_date: 'yyyy-MM-dd HH:mm' (ou datetime)."""
        params = {
            "idProspect": int(id_prospect),
            "activityDate": fmt_datetime_evo(activity_date),
            "activity": activity,
            "service": service,
        }
        if id_activity:
            params["idActivity"] = int(id_activity)
        if id_service:
            params["idService"] = int(id_service)
        if activity_exist is not None:
            params["activityExist"] = bool(activity_exist)
        bid = self._bid(branch_id)
        if bid:
            params["idBranch"] = bid
        data = self._request("POST", "/api/v1/activities/schedule/experimental-class", params=params)
        id_session = (data or {}).get("idActivitySession")
        log.info("Aula experimental agendada: idActivitySession=%s (prospect=%s, %s)",
                 id_session, id_prospect, params["activityDate"])
        return id_session


# ---------------- helpers de módulo ----------------
def _drop_empty(d):
    if not d:
        return d
    return {k: v for k, v in d.items() if v not in (None, "")}


def _error_detail(resp):
    try:
        data = resp.json()
        if isinstance(data, dict):
            if data.get("mensagens"):
                return "; ".join(str(m) for m in data["mensagens"])
            # EVO costuma devolver {"errors": [{"value": "..."}]}
            if isinstance(data.get("errors"), list) and data["errors"]:
                msgs = [str(e.get("value") or e.get("message") or e)
                        for e in data["errors"] if isinstance(e, dict)]
                if msgs:
                    return "; ".join(msgs)
            if data.get("message"):
                return str(data["message"])
            if data.get("detail"):
                return str(data["detail"])
    except ValueError:
        pass
    return (resp.text or "").strip()[:500]
